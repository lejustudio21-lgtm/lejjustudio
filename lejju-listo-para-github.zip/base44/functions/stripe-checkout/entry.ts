import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';
import Stripe from 'npm:stripe@16.2.0';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json();

    const { items, type, serviceRequestId, courseTitle, successUrl, cancelUrl } = body;

    if (!items || !Array.isArray(items) || items.length === 0) {
      return Response.json({ error: 'Items required' }, { status: 400 });
    }

    const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY'));

    // Try to get the user (app is public, so may not be authenticated)
    let user = null;
    let userEmail = null;
    try {
      user = await base44.auth.me();
      if (user) userEmail = user.email;
    } catch {}

    const lineItems = items.map((item) => ({
      price_data: {
        currency: 'usd',
        product_data: {
          name: item.name,
        },
        unit_amount: Math.round(item.price * 100),
      },
      quantity: item.quantity || 1,
    }));

    const total = items.reduce((sum, item) => sum + item.price * (item.quantity || 1), 0);

    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items: lineItems,
      mode: 'payment',
      success_url: successUrl || `${req.headers.get('origin')}/perfil`,
      cancel_url: cancelUrl || `${req.headers.get('origin')}/tienda`,
      customer_email: userEmail || undefined,
      metadata: {
        base44_app_id: Deno.env.get('BASE44_APP_ID'),
        type: type || 'product',
        user_id: user?.id || '',
        user_email: userEmail || '',
        service_request_id: serviceRequestId || '',
        course_title: courseTitle || '',
        total: total.toString(),
      },
    });

    // Create a pending order if user is authenticated
    if (user) {
      try {
        await base44.entities.Order.create({
          user_id: user.id,
          user_email: userEmail,
          items: items.map((item) => ({
            name: item.name,
            price: item.price,
            quantity: item.quantity || 1,
          })),
          total,
          status: 'pendiente',
        });
      } catch (e) {
        console.log('Order creation skipped:', e.message);
      }
    }

    return Response.json({ url: session.url, sessionId: session.id });
  } catch (error) {
    console.error('Stripe checkout error:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});