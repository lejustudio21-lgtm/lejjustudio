import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { MessageSquare, Send, Heart, Pin } from 'lucide-react';

export default function AdminCommunity() {
  const [posts, setPosts] = useState([]);
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [subtab, setSubtab] = useState('posts');

  useEffect(() => {
    const load = async () => {
      try {
        const [p, m] = await Promise.all([
          base44.entities.ForumPost.list('-created_date', 30).catch(() => []),
          base44.entities.ChatMessage.list('-created_date', 30).catch(() => []),
        ]);
        setPosts(p || []);
        setMessages(m || []);
      } catch {}
      setLoading(false);
    };
    load();

    const unsubPosts = base44.entities.ForumPost.subscribe((event) => {
      if (event.type === 'create') setPosts((p) => [event.data, ...p]);
    });
    const unsubMsgs = base44.entities.ChatMessage.subscribe((event) => {
      if (event.type === 'create') setMessages((m) => [event.data, ...m]);
    });
    return () => { unsubPosts(); unsubMsgs(); };
  }, []);

  if (loading) {
    return <div className="flex justify-center py-20"><div className="w-8 h-8 border-2 border-white/10 border-t-gold rounded-full animate-spin" /></div>;
  }

  return (
    <div className="space-y-4">
      {/* Subtabs */}
      <div className="flex justify-center gap-2">
        <button onClick={() => setSubtab('posts')} className={`px-4 py-2 rounded-full text-xs font-heading tracking-wider transition-all flex items-center gap-1.5 ${subtab === 'posts' ? 'bg-white/5 text-gold border border-white/20' : 'text-muted-silver border border-carbon hover:text-silver'}`}>
          <Pin size={12} strokeWidth={1.5} /> Foro ({posts.length})
        </button>
        <button onClick={() => setSubtab('chat')} className={`px-4 py-2 rounded-full text-xs font-heading tracking-wider transition-all flex items-center gap-1.5 ${subtab === 'chat' ? 'bg-white/5 text-gold border border-white/20' : 'text-muted-silver border border-carbon hover:text-silver'}`}>
          <MessageSquare size={12} strokeWidth={1.5} /> Chat ({messages.length})
        </button>
      </div>

      {subtab === 'posts' ? (
        <div className="space-y-3">
          {posts.length === 0 ? (
            <p className="text-center text-muted-silver text-sm py-10">Sin actividad en el foro</p>
          ) : (
            posts.map((post, i) => (
              <div key={post.id || i} className="glass-card rounded-xl p-4">
                <div className="flex items-center justify-between mb-1">
                  <p className="text-xs font-heading text-silver">{post.author_name}</p>
                  <div className="flex items-center gap-2">
                    {post.is_pinned && <Pin size={10} className="text-gold" />}
                    <span className="text-[0.6rem] text-muted-silver">{new Date(post.created_date).toLocaleString('es-UY', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })}</span>
                  </div>
                </div>
                <p className="text-sm text-silver/70 leading-relaxed font-body">{post.content}</p>
                <div className="flex items-center gap-1 mt-2">
                  <Heart size={11} strokeWidth={1.5} className="text-muted-silver" />
                  <span className="text-[0.65rem] text-muted-silver">{post.reactions || 0}</span>
                  <span className="ml-2 text-[0.65rem] text-muted-silver/50 capitalize">· {post.post_type}</span>
                </div>
              </div>
            ))
          )}
        </div>
      ) : (
        <div className="space-y-2">
          {messages.length === 0 ? (
            <p className="text-center text-muted-silver text-sm py-10">Sin mensajes en el chat</p>
          ) : (
            messages.map((msg, i) => (
              <div key={msg.id || i} className="glass-card rounded-xl p-3 flex items-start gap-3">
                <div className="w-7 h-7 rounded-full bg-white/5 border border-carbon flex items-center justify-center flex-shrink-0">
                  <Send size={11} strokeWidth={1.5} className="text-gold/60" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <p className="text-xs font-heading text-silver">{msg.author_name}</p>
                    <span className="text-[0.6rem] text-muted-silver">{new Date(msg.created_date).toLocaleString('es-UY', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })}</span>
                  </div>
                  <p className="text-sm text-silver/70 mt-0.5">{msg.content}</p>
                </div>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
}